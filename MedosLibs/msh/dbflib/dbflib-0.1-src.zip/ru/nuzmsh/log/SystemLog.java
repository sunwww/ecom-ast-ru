package ru.nuzmsh.log;

import java.io.* ;

/**
 *
 */
public class SystemLog {

    private static final boolean CAN_TRACE  ;

    static {
        CAN_TRACE = System.getProperty("CAN_TRACE")!=null ;
    }

    public static boolean canTrace() {
        return CAN_TRACE ;
    }
    public static void ERROR(Object aObject, Exception e) {
        System.out.println(aObject);
        e.printStackTrace() ;
            try {
                PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream("trace.log", true),"Cp1251"));
                out.println(aObject) ;
                e.printStackTrace(out) ;
                out.close() ;
            } catch (Exception ex) {
                ex.printStackTrace() ;
            }
    }
    
    public static void TRACE(Object aObject) {
        if(CAN_TRACE) {
            System.out.println(aObject);
            try {
                PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream("trace.log", true),"Cp1251"));
                out.println(aObject) ;
                out.close() ;
            } catch (Exception e) {
                e.printStackTrace() ;
            }
        }
    }
}
