package ru.nuzmsh.log;

/**
 * @author esinev
 * Date: 30.01.2006
 * Time: 9:54:13
 */
public class Logger {

    private Logger(java.util.logging.Logger aLogger) {
        theLogger = aLogger ;
        theLogger.setLevel(java.util.logging.Level.ALL);
    }

    public void warn(CharSequence aMessage) {
        if(aMessage!=null) {
            theLogger.warning(aMessage.toString());
        }
    }

    public void warn(CharSequence aMessage, Exception e) {
        if(aMessage!=null) {
            theLogger.warning(aMessage.toString() + " " +e);
            e.printStackTrace()  ;
        }
    }

    public void trace(CharSequence aMessage) {
        System.out.print(theLogger.getName())  ;
        System.out.print(" TRACE: ");
        System.out.println(aMessage);
    }

    private final java.util.logging.Logger theLogger ;

    public static Logger getLogger(Class aClass) {
        return new Logger(java.util.logging.Logger.getLogger(aClass.getName())) ;
    }


}
