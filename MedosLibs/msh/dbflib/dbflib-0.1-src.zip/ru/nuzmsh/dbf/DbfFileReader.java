package ru.nuzmsh.dbf;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.util.HashMap;
import java.util.Date;
import java.nio.channels.FileChannel;
import java.nio.MappedByteBuffer;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.math.BigDecimal;

/**
 * Чтение файла DBF
 * @author esinev
 *         Date: 28.01.2006
 *         Time: 18:35:18
 */
public class DbfFileReader {

    /**
     * Создание
     * @param aFile  файл DBF
     * @throws IOException
     * @throws ParseException
     */
    public DbfFileReader(File aFile) throws IOException, ParseException {
        InputStream in = new FileInputStream(aFile);
        //theChannel = in.getChannel();
        theDbf = new DbfFile();
        theDbf.load(in) ; //theChannel);
        theCurrentPosition = 0;

        theHeaderLength = theDbf.getHeader().getHeaderLength();
        theRecordLength = theDbf.getHeader().getRecordLength();
        theFields = theDbf.getFields();
        in.close() ;

        long start = theHeaderLength ;
                //+ theRecordLength * 1;


        theIn = new FileInputStream(aFile);
        ru.nuzmsh.log.SystemLog.TRACE("start = " + start);

        theIn.skip(start) ;

    }

//    private static ByteBuffer read(InputStream aIn, int aSize) throws IOException {
//        byte[] bytes= new byte[aSize] ;
//        aIn.read(bytes) ;
////        ru.nuzmsh.log.SystemLog.TRACE("bytes = " + new String(bytes));
//        return ByteBuffer.wrap(bytes) ;
//    }


    public boolean next() {
        return theCurrentPosition++ < theDbf.getRecordsCount();
    }

    private final long theHeaderLength;
    private final long theRecordLength;
    private final Object[] theFields;

    public HashMap<String, Object> load(HashMap<String, Object> aHash) throws IOException, ParseException {
//        long start = theHeaderLength
//                + theRecordLength * (theCurrentPosition - 1);
//
//        ru.nuzmsh.log.SystemLog.TRACE("start = " + start +" theRecordLength="+theRecordLength
//                +" theHeaderLength="+theHeaderLength+" theCurrentPosition="+theCurrentPosition);

//        MappedByteBuffer buf = theChannel.map(FileChannel.MapMode.READ_ONLY
//                , start
//                , theRecordLength);
        //ByteBuffer buf = read(theIn, (int)theRecordLength-1) ;


        byte[] b = new byte[(int)theRecordLength] ;
        theIn.read(b) ;

//        buf.order(ByteOrder.LITTLE_ENDIAN);

        //buf.get() ;
//        byte b[] = new byte[buf.capacity()];
//        buf.get(b);
        int length = theFields.length;
        for (int i = 0; i < length; i++) {
            DbfField field = (DbfField) theFields[i];
            //buf.get(b, field.getFieldOffset(), field.getLength()) ;


            String str = new String(b, field.getFieldOffset(), field.getLength(), "Cp866") ;
//            ru.nuzmsh.log.SystemLog.TRACE(field.getName() + " length ="+field.getLength() + " str = '" + str+"'");
//            if(field.getName().equals("IM")) {
//                ru.nuzmsh.log.SystemLog.TRACE("str = " + str+"'");
//            }
            str = str.trim() ;
            switch (field.getType()) {
                case DbfField.DATE:
                    if (!str.equals("")) {
                        Date date = DATE_FORMAT.parse(str);
                        java.sql.Date sqlDate = new java.sql.Date(date.getTime());
                        aHash.put(field.getName(), sqlDate);
                    } else {
                        aHash.remove(field.getName());
                    }
                    break;
                case DbfField.NUMERIC:
                    if (!str.equals("")) {
                        BigDecimal num = new BigDecimal(str);
                        aHash.put(field.getName(), num);
                    } else {
                        aHash.remove(field.getName());
                    }
                default:
                    aHash.put(field.getName(), str);
                    break;
            }
        }

        //trace(buf) ;

//        theCurrentPosition++ ;
        return null;
    }

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");

    private void trace(ByteBuffer aByteBuffer) {
        ru.nuzmsh.log.SystemLog.TRACE("aByteBuffer = " + aByteBuffer);
        int oldPosition = aByteBuffer.position();

        for (int c = 0; c < aByteBuffer.limit(); c++) {
            if ((c % 4) == 0 && c != 0) {
                System.out.print(" | ");
            } else if ((c % 8) == 0) {
                System.out.print("\n");
            }
            System.out.print(" ");
            System.out.print(aByteBuffer.get());
            c++;
        }
        aByteBuffer.position(oldPosition);
        System.out.print("\n");
    }


    public void close() throws IOException {
        theIn.close();
    }


    private final DbfFile theDbf;
//    private final FileChannel theChannel;
    private final InputStream theIn ;
    private long theCurrentPosition = 0;

//    private static Charset charset = Charset.forName("cp866");
//    private static CharsetDecoder decoder = charset.newDecoder();

    public long getRowsCount() {
        return theDbf.getRecordsCount() ;
    }
}
