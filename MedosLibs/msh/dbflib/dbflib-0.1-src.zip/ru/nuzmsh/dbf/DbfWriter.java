package ru.nuzmsh.dbf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Date;
import java.nio.channels.FileChannel;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;

/**
 * Запись файла DBF
 *
 * @author esinev
 * Date: 28.01.2006
 * Time: 18:06:47
 */
public class DbfWriter {

    /**
     * Создание файла DBF
     * @param aRecordsCount количество записей
     * @param aDbfFields    описание полей
     */
    public DbfWriter(int aRecordsCount, Collection<DbfField> aDbfFields) {
        theDbfFields = aDbfFields;

        theHeader.setVersion(3);
        theHeader.setLastUpdate(new Date());
        theHeader.setRecordsCount(aRecordsCount);
        theHeader.load(aDbfFields);
        ru.nuzmsh.log.SystemLog.TRACE("theHeader = " + theHeader);
        theValuesBuffer = ByteBuffer.allocateDirect(theHeader.getRecordLength()-1) ;
//        theValuesBuffer.order(ByteOrder.LITTLE_ENDIAN);
    }

    FileOutputStream out ;
    FileChannel channel ;
    public void open(File aFile) throws IOException {
        out = new FileOutputStream(aFile);
        channel = out.getChannel() ;

        // заголовок файла
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(DbfFileHeader.SIZE) ;
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
        theHeader.store(byteBuffer) ;
        byteBuffer.rewind() ;
        ru.nuzmsh.log.SystemLog.TRACE("byteBuffer = " + byteBuffer);
        channel.write(byteBuffer) ;

        // описание полей
        byteBuffer = ByteBuffer.allocateDirect(theDbfFields.size()*32) ;
        byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
        int fieldOffset = 1 ;
        for (DbfField field : theDbfFields) {
            field.setFieldOffset(fieldOffset);
            field.storeHeader(byteBuffer, fieldOffset) ;
            fieldOffset += field.getLength() ;
            ru.nuzmsh.log.SystemLog.TRACE("field = " + field);
        }
        byteBuffer.rewind() ;
        channel.write(byteBuffer) ;

        // 0x0D
        byteBuffer = ByteBuffer.allocateDirect(1) ;
        byteBuffer.put((byte) 0x0D) ;
        byteBuffer.rewind() ;
        channel.write(byteBuffer) ;
    }

    public void write(HashMap<String, Object>  aValues) throws IOException {
        // 0x0D
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(1) ;
        byteBuffer.put((byte) 0x20) ;
        byteBuffer.rewind() ;
        channel.write(byteBuffer) ;

        ByteBuffer buf = theValuesBuffer ;
        buf.rewind() ;
        //
        for (DbfField field : theDbfFields) {
            Object value = aValues.get(field.getName()) ;
            field.storeValue(value, buf);
        }
        buf.rewind() ;
        channel.write(buf) ;


    }

    public void close() throws IOException {
        // 0x1A
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(1) ;
        byteBuffer.put((byte) 0x1A) ;
        byteBuffer.rewind() ;
        channel.write(byteBuffer) ;
        channel.close();
        out.flush();
        out.close() ;
    }


    private final DbfFileHeader theHeader = new DbfFileHeader();
    private final Collection<DbfField> theDbfFields ;
    private final ByteBuffer theValuesBuffer ;
}
