package ru.nuzmsh.dbf;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Date;
import java.util.ArrayList;

/**
 * Created by IntelliJ IDEA.
 * User: esinev
 * Date: 29.01.2006
 * Time: 0:02:54
 * To change this template use File | Settings | File Templates.
 */
public class TestDbf {

    /**
     * ru.nuzmsh.dbf.DbfFile TRACE: header = version=3, date=23.01.2006, recordsCount=4, headerLength=193, recordLength=61
     * ru.nuzmsh.dbf.DbfFile TRACE: field = name='OSL', type=C, fieldOffset=1, length=1, decimalLength=0
     * ru.nuzmsh.dbf.DbfFile TRACE: field = name='NAME', type=C, fieldOffset=2, length=30, decimalLength=0
     * ru.nuzmsh.dbf.DbfFile TRACE: field = name='WHEND', type=D, fieldOffset=32, length=8, decimalLength=0
     * ru.nuzmsh.dbf.DbfFile TRACE: field = name='WHENU', type=C, fieldOffset=40, length=20, decimalLength=0
     * ru.nuzmsh.dbf.DbfFile TRACE: field = name='WHAT', type=N, fieldOffset=60, length=1, decimalLength=0
     */
    public static void testWrite() throws IOException {

    }


    public static void testRead() throws IOException, ParseException {

        ArrayList<DbfField> fields = new ArrayList<DbfField>();

        fields.add(new DbfField("OSL", DbfField.CHAR, 1));
        fields.add(new DbfField("NAME", DbfField.CHAR, 30));
        fields.add(new DbfField("WHEND", DbfField.DATE));
        fields.add(new DbfField("WHENU", DbfField.CHAR, 20, 0));
        fields.add(new DbfField("WHAT", DbfField.NUMERIC, 1, 0));

        DbfWriter out = new DbfWriter(4, fields);
        out.open(new File("../lpufix-data/proba.dbf"));

        ru.nuzmsh.log.SystemLog.TRACE("new Date() = " + new Date());
        DbfFileReader in; //= new DbfFileReader(new File("../lpufix-data/test.dbf"));
        in = new DbfFileReader(new File("../lpufix-data/osl.DBF"));
        HashMap<String, Object> hash = new HashMap<String, Object>();
        int i = 0;
        while (in.next()) {
            i++;
            in.load(hash);
            if (i % 10000 == 0)
                ru.nuzmsh.log.SystemLog.TRACE("hash = " + hash);
            out.write(hash);

        }

        out.close();

        //in = new DbfFileReader(new File("../lpufix-data/s11_n.dbf"));
        ru.nuzmsh.log.SystemLog.TRACE("new Date() = " + new Date());
    }

    public static void main(String[] args) throws IOException, ParseException {
        testRead();
        testWrite();
    }
}
