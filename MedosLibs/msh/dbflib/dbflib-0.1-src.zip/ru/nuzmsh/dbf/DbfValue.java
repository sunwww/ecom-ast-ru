package ru.nuzmsh.dbf;

/**
 * Значение поля DBF
 * User: esinev
 * Date: 31.01.2006
 * Time: 23:02:18
 */
public class DbfValue {

    /**
     * Создание значение DBF
     * @param aName  название поля
     * @param aValue само значение
     * @param aType  тип см. DbfField.CHAR, DbfField.NUMERIC, DbfField.DATE
     */
    public DbfValue(String aName, Object aValue, int aType) {
        theName = aName;
        theValue = aValue;
        theType = aType ;
    }

    /** Название поля */
    public String getName() { return theName ; }
    public void setName(String aName) { theName = aName ; }

    /** Тип данных */
    public int getType() { return theType ; }
    public void setType(int aType) { theType = aType ; }

    /** Значение */
    public Object getValue() { return theValue ; }
    public void setValue(Object aValue) { theValue = aValue ; }

    /** Значение */
    private Object theValue ;
    /** Тип данных */
    private int theType ;
    /** Название поля */
    private String theName ;
}
