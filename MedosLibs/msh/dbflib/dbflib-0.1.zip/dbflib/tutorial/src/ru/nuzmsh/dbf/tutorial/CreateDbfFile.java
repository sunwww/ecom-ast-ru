package ru.nuzmsh.dbf.tutorial;

import ru.nuzmsh.dbf.DbfField;
import ru.nuzmsh.dbf.DbfWriter;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.text.ParseException;

/**
 * Пример создания файла DBF
 */
public class CreateDbfFile {

    public static void main(String[] args) throws IOException, ParseException {
        File file = new File(args.length>0 ? args[0] : "proba.dbf") ;
        new CreateDbfFile().createDbfFile(file);
    }

    public void createDbfFile(File aFile) throws IOException, ParseException {

        // описание структури файла
        ArrayList<DbfField> fields = new ArrayList<DbfField>();
        fields.add(new DbfField("OSL"   , DbfField.CHAR, 1));
        fields.add(new DbfField("NAME"  , DbfField.CHAR, 30));
        fields.add(new DbfField("WHEND" , DbfField.DATE));
        fields.add(new DbfField("WHENU" , DbfField.CHAR, 20, 0));
        fields.add(new DbfField("WHAT"  , DbfField.NUMERIC, 1, 0));

        // создание потока вывода для DBF файл
        DbfWriter out = new DbfWriter(4, fields);
        out.open(aFile);
        // запись 1
        out.write(createRecord("1", "Без осложнений", parseDate("32.12.2005"), "nobody", 1 ));
        // запись 2
        out.write(createRecord("5", "С осложнениями", parseDate("12.12.2005"), "nobody", 2 ));
        // запись 3
        out.write(createRecord("7", "Патология", parseDate("13.12.2005"), "nobody", 1 ));
        // запись 4
        out.write(createRecord("2", "Осложнение + патология", parseDate("01.04.2006"), "nobody", 4 ));

        // закрытие потока и файла
        out.close() ;

        System.out.println("Создан файл: "+aFile.getAbsolutePath());
    }

    private HashMap<String, Object> createRecord(String aId, String aName, Date aDate, String aWho, int aWhat) {
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("OSL", aId) ;
        map.put("NAME", aName) ;
        map.put("WHEND", aDate) ;
        map.put("WHENU", aWho) ;
        map.put("WHAT", aWhat) ;
        return map ;
    }

    private static Date parseDate(String aString) throws ParseException {
        return new SimpleDateFormat("dd.MM.yyyy").parse(aString) ;
    }

}
