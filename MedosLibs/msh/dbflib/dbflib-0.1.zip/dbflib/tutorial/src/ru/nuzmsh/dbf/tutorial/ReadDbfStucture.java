package ru.nuzmsh.dbf.tutorial;

import ru.nuzmsh.dbf.DbfFile;
import ru.nuzmsh.dbf.DbfFileHeader;
import ru.nuzmsh.dbf.DbfField;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.Collection;

/**
 * Чтение структуры DBF
 */
public class ReadDbfStucture {


    public static void main(String[] args) throws IOException, ParseException {
        new ReadDbfStucture().readDbfStucture(
                new File(args.length>0?args[0]:"proba.dbf")
        ) ;
    }

    private void readDbfStucture(File aFile) throws IOException, ParseException {
        // создаем объект файла DBF
        DbfFile dbfFile = new DbfFile();

        // создаем поток для файла
        FileInputStream in = new FileInputStream(aFile);

        // загружаем заголовок файла DBF
        dbfFile.load(in);

        System.out.println("--------------- " );
        System.out.println("Количество записей = " + dbfFile.getRecordsCount());

        // Список полей
        Collection<DbfField> fields = dbfFile.getDbfFields() ;

        System.out.println("Количество полей = " + fields.size());
        System.out.println("Список полей");
        for (DbfField field : fields) {
            System.out.print("  "+field.getName());
            System.out.print("\t, размер = "+field.getLength());
            System.out.print("\t, тип = "+field.getType() +" (");
            String fieldTypeName ;
            switch(field.getType()) {
                case DbfField.CHAR: fieldTypeName = "строка"; break ;
                case DbfField.NUMERIC: fieldTypeName = "число"; break ;
                case DbfField.DATE: fieldTypeName = "дата"; break ;
                default:
                    fieldTypeName = "неизвестный тип" ;
            }
            System.out.println(fieldTypeName +")");
        }

        in.close() ;
    }
}
