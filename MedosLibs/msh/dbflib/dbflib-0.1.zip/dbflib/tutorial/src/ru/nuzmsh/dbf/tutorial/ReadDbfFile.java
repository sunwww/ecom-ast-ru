package ru.nuzmsh.dbf.tutorial;

import ru.nuzmsh.dbf.DbfFileReader;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.text.ParseException;

/**
 * Пример чтения из файла DBF
 */
public class ReadDbfFile {


    public static void main(String[] args) throws IOException, ParseException {
        File file ;
        if(args.length>0) {
            file = new File(args[0]) ;
        } else {
            file = new File("proba.dbf") ;
        }

        new ReadDbfFile().readDbfFile(file) ;
    }

    private void readDbfFile(File aFile) throws IOException, ParseException {
        // создание потока для чтения файла DBF
        DbfFileReader in =  new DbfFileReader(aFile);
        // здесь будут значение полей
        HashMap<String, Object> hash = new HashMap<String, Object>();
        System.out.println("\n--------------------");
        System.out.println("Количество записей = " + in.getRowsCount());

        
        int record = 0 ;
        while(in.next()) {
            record ++ ;

            // загружаем значения полей
            in.load(hash) ;

            // выводим значение поля NAME
            System.out.println("Значение поля NAME = " + hash.get("NAME"));

            // выводим все значения
            System.out.println("Запись № " + record);
            for (String key : hash.keySet()) {
                System.out.print("   ") ;
                System.out.print(key) ;
                System.out.print(" = ") ;
                System.out.println(hash.get(key));
            }

            // очищаем от предыдущих значений
            hash.clear();
        }
        // закрывае поток и файл
        in.close();

    }
}
