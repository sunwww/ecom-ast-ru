java -cp ../dbflib-0.1.jar:./classes ru.nuzmsh.dbf.tutorial.ReadDbfStucture
