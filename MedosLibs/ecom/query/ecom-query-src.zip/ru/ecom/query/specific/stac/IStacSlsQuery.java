package ru.ecom.query.specific.stac;

import ru.ecom.query.result.IQueryResult;

import java.util.Date;
import java.util.Set;
import java.rmi.RemoteException;

/**
 * Запрос в стационар за данными по СЛС
 */
public interface IStacSlsQuery {
    public IQueryResult querySls(Date aFromDate, Date aToDate, Set<String> aFields) throws RemoteException ;
}
