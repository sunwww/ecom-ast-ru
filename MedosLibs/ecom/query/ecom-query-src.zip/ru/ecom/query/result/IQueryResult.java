package ru.ecom.query.result;

import java.io.Serializable;

/**
 * Результат выполнения запроса
 */
public interface IQueryResult extends Serializable {

    public boolean next() throws QueryResultException ;
    public void close() throws QueryResultException ;
    public Object getObject(String aColumn) throws QueryResultException ;
    public String getCurrentCursorString() ;
}
