package ru.ecom.query.result;

/**
 * Ошибка
 */
public class QueryResultException extends Exception {
    public QueryResultException(String message) {
        super(message);    //To change body of overridden methods use File | Settings | File Templates.
    }

    public QueryResultException(String message, Throwable cause) {
        super(message, cause);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
