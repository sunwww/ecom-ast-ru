package ru.ecom.query.impl.result.array;

import java.io.Serializable;
import java.util.TreeMap;

/**
 * Строка
 */
public class ArrayQueryResultRow implements Serializable {

    public void put(String aName, Object aValue) {
        theMap.put(aName, aValue) ;
    }

    public Object get(String aName) {
        return theMap.get(aName) ;
    }

    public String toString() {
        return getClass().getSimpleName()+" "+theMap ;
    }

    private final TreeMap<String, Object> theMap = new TreeMap<String, Object>();
}
