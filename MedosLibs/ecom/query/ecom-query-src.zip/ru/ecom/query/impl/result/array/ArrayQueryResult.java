package ru.ecom.query.impl.result.array;

import ru.ecom.query.result.IQueryResult;
import ru.ecom.query.result.QueryResultException;

import java.util.LinkedList;
import java.util.Iterator;

/**
 *
 */
public class ArrayQueryResult implements IQueryResult {

    public boolean next() throws QueryResultException {
        if(theIterator==null) {
            theIterator = theList.iterator();
        }

        if(theIterator.hasNext()) {
            theLastRow = theIterator.next() ;
            return true ;
        } else {
            return false ;
        }
    }

    public String getCurrentCursorString() {
        return theLastRow!=null ? theLastRow.toString() : "Нет данных" ;
    }

    public void close() throws QueryResultException {
    }

    public Object getObject(String aColumn) throws QueryResultException {
        ArrayQueryResultRow row = theLastRow ;
        return row.get(aColumn) ;
    }

    public void addRow(ArrayQueryResultRow aRow) {
        theList.add(aRow) ;
    }

    public ArrayQueryResultRow newAndAddRow() {
        ArrayQueryResultRow row = new ArrayQueryResultRow();
        theList.add(row) ;
        return row ;
    }

    private boolean theIsOpen = false;
    private Iterator<ArrayQueryResultRow> theIterator = null ;
    private ArrayQueryResultRow theLastRow = null ;
    private final LinkedList<ArrayQueryResultRow> theList = new LinkedList<ArrayQueryResultRow>();
}
