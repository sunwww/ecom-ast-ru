package ru.amokb.repriams.ejb.domain;

import javax.persistence.Entity;

import ru.ecom.ejb.domain.simple.BaseEntity;
import ru.ecom.ejb.domain.simple.VocBaseEntity;

@Entity
public class ReportJournal extends VocBaseEntity {

}
