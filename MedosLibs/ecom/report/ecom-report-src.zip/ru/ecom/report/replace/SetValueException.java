package ru.ecom.report.replace;

/**
 *
 */
public class SetValueException extends Exception {
    public SetValueException(String message, Throwable cause) {
        super(message, cause);
    }
}
