package ru.ecom.report.excel;

/**
 *
 */
public class ReportEngineMakeException extends Exception {
    public ReportEngineMakeException(String message, Throwable cause) {
        super(message, cause);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
