package ru.ecom.report.rtf;

import ru.ecom.report.replace.BshValueGetter;

/**
 *  Получение значений для RTF
 */
class DefaultRtfValueGetter extends BshValueGetter  {

}
