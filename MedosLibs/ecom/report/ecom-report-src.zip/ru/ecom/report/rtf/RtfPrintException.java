package ru.ecom.report.rtf;

/**
 * @author esinev
 * Date: 10.10.2006
 * Time: 16:35:34
 */
public class RtfPrintException extends Exception {

    public RtfPrintException(String message) {
        super(message);    //To change body of overridden methods use File | Settings | File Templates.
    }

    public RtfPrintException(String message, Throwable cause) {
        super(message, cause);    //To change body of overridden methods use File | Settings | File Templates.
    }
}
